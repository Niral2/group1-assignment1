﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSinister_Click(object sender, RoutedEventArgs e)
        {
            lblEng.Content = "left";
            lblEng.Visibility = Visibility.Visible;
            lblEngRight.Visibility = Visibility.Hidden;
            lblEngCenter.Visibility = Visibility.Hidden;


            
            
         
        }

        private void btnDexter_Click(object sender, RoutedEventArgs e)
        {
            lblEngRight.Content = "right";
            lblEngRight.Visibility = Visibility.Visible;
            lblEng.Visibility = Visibility.Hidden;
            lblEngCenter.Visibility = Visibility.Hidden;
        }

        private void btnMedium_Click(object sender, RoutedEventArgs e)
        {
            lblEngCenter.Content = "center";
            lblEngCenter.Visibility = Visibility.Visible;
            lblEng.Visibility = Visibility.Hidden;
            lblEngRight.Visibility = Visibility.Hidden;
        }

        
    }
}
